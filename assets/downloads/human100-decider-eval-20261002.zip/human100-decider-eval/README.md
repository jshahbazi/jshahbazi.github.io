# Human100 decider evaluation

This is the same 100-case answer-grading development dataset used in our Jev, Jeff, Jeeves, JevK5, Clef and Strands Decider comparisons. It comes from the VA-handbook recall workflow and includes candidate answers, reference facts, source evidence and human binary adjudications at revision 121.

There are **67 human-accepted answers and 33 human-rejected answers**. Always accepting scores **67% agreement**. The set has been used repeatedly for development; results describe this dataset and do not establish fresh held-out or production accuracy.

## Files

- `cases.jsonl`: 100 cases in a simple model-independent schema. `candidate_answer` is the answer being graded; `reference_fact` is the reference. `source_context` is optional evidence for the E1 arm.
- `requests.jsonl`: 200 ready-to-use request bodies, one J0 and one E1 request per case, in the original order and with the unchanged grading rubric.
- `labels.jsonl`: 100 human labels, joined by `case_id`. Keep these out of model inputs.
- `score.py`: dependency-free scoring for normalized verdicts from your own model.
- `manifest.json` and `SHA256SUMS`: counts, input lineage hashes and package integrity checks.

Case IDs are export-local aliases. Reviewer notes, reviewer identities, private tenant/run/document/fact identifiers and prior models' individual judgments are omitted. The original question, reference, candidate answer, critical entities, source-context text and request rubric are preserved.

## Run your model

Unzip and verify the files:

```bash
cd human100-decider-eval
shasum -a 256 -c SHA256SUMS
```

Read each row of `requests.jsonl` and send its `request` to your decider. The wrapper's `case_id` and `context` are output bookkeeping, not model inputs. J0 provides the question, reference fact, candidate answer and critical entities. E1 adds the original source evidence. Preserve the question instructions, option order and all rubric clauses for an equivalent comparison.

The historical request body contains `"model": "jeff-latest"` as a routing placeholder. Replace it with your server's model identifier if required; it does not select Jeff for local/native implementations. The verdict has three options: `correct`, `incorrect`, `partial`. A native API that only accepts string criterion descriptions needs a deterministic conversion of the ordered clause lists, preserving every clause; document that adapter. Strands used its native JSON renderer for that conversion.

Use complete inputs without truncation, preferably an 8,192-token window or larger after native formatting. Two E1 cases exceeded 4,096 tokens in the Strands renderer. Token counts depend on the model's tokenizer and format.

For our comparison protocol, run all 200 requests once in file order, then run them again in the same order with `repeat: 2`. Disable cross-request caching. Record normalized predictions as JSONL:

```json
{"case_id":"human100-001","context":"J0","repeat":1,"choice":"correct","latency_ms":100.0}
```

Use your returned verdict in `choice`. `latency_ms` is optional; when supplied, measure the complete decision consistently and exclude model loading. This example is a format illustration, not a saved model judgment. One pass, J0 only or E1 only is also supported by the scorer.

## Score predictions

```bash
python3 score.py predictions.jsonl
```

Only `correct` means accepted; `partial` and `incorrect` mean rejected. The scorer reports agreement, false accepts, false rejects, three-way counts, repeat flips when both passes are supplied, and latency statistics when present. A false accept is accepting an answer whose human label is `rejected`; a false reject is rejecting an answer whose human label is `accepted`.

Each context/pass must contain all 100 cases exactly once. With two passes, counts span 200 judgments per context but still represent only 100 unique cases. The scorer rejects missing, duplicate and malformed rows.

## Reference agreement on this same dataset

These are saved results over two passes per context, using different native formats and released model recipes. They are a reference for within-set comparison, not matched runtime or general accuracy claims.

| Model | J0 | E1 |
| --- | ---: | ---: |
| Always accept | 67% | 67% |
| Saved Jev | 90% | 88.5% |
| JevK5-4B v0.3 | 89% | 88% |
| Mapika Decider-4B v2 | 86% | 86% |
| Jeeves 9B, no reasoning | 84% | 85% |
| JevK5-9B v0.3.3 | 82% | 88% |
| Jeff 0.8B, original | 81% | 72% |
| Clef-flash 9B | 80% | 79% |
| Strands Decider 2B v19 | 73% | 68% |

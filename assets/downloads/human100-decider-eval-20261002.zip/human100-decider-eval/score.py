#!/usr/bin/env python3
"""Score Human100-compatible predictions against labels.jsonl beside this file."""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

CHOICES = {"correct", "incorrect", "partial"}
CONTEXTS = {"J0", "E1"}


def fail(message: str) -> None:
    raise ValueError(message)


def rows(path: Path) -> list[dict]:
    try:
        result = []
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    value = json.loads(line)
                    if not isinstance(value, dict):
                        fail("invalid row")
                    result.append(value)
        return result
    except (OSError, json.JSONDecodeError, UnicodeError) as exc:
        raise ValueError("cannot read input") from exc


def labels(path: Path) -> dict[str, str]:
    parsed = rows(path)
    if len(parsed) != 100:
        fail("labels must contain exactly 100 rows")
    result = {}
    for row in parsed:
        if set(row) != {"case_id", "human_label"}:
            fail("invalid label schema")
        case_id, label = row["case_id"], row["human_label"]
        if not isinstance(case_id, str) or not isinstance(label, str):
            fail("invalid label value")
        if label not in {"accepted", "rejected"} or case_id in result:
            fail("invalid labels")
        result[case_id] = label
    counts = Counter(result.values())
    if counts != Counter({"accepted": 67, "rejected": 33}):
        fail("labels must contain 67 accepted and 33 rejected")
    return result


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * fraction
    lower, upper = math.floor(position), math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def score(prediction_path: Path, label_path: Path) -> dict:
    gold = labels(label_path)
    predictions = rows(prediction_path)
    if not predictions:
        fail("predictions are empty")
    grouped: dict[tuple[str, int], list[dict]] = defaultdict(list)
    for row in predictions:
        required = {"case_id", "context", "choice"}
        if not required.issubset(row) or not isinstance(row["case_id"], str):
            fail("invalid prediction schema")
        case_id, context, choice = row["case_id"], row["context"], row["choice"]
        repeat = row.get("repeat", 1)
        if not isinstance(context, str) or not isinstance(choice, str):
            fail("invalid prediction value")
        if case_id not in gold or context not in CONTEXTS or choice not in CHOICES:
            fail("invalid prediction value")
        if isinstance(repeat, bool) or not isinstance(repeat, int) or repeat not in {1, 2}:
            fail("invalid prediction value")
        latency = row.get("latency_ms")
        if latency is not None and (
            isinstance(latency, bool)
            or not isinstance(latency, (int, float))
            or not math.isfinite(latency)
            or latency < 0
        ):
            fail("invalid latency")
        grouped[(context, repeat)].append(row)
    for group in grouped.values():
        ids = [row["case_id"] for row in group]
        if len(group) != 100 or len(set(ids)) != 100 or set(ids) != set(gold):
            fail("each observed context and repeat must contain all 100 cases exactly once")
    for context in CONTEXTS:
        groups = [group for (ctx, _), group in grouped.items() if ctx == context]
        if groups:
            presence = {row.get("latency_ms") is not None for group in groups for row in group}
            if len(presence) > 1:
                fail("latency presence must be consistent within context")

    output = {"cases": 100, "contexts": {}, "overall": {}}
    all_stats = []
    for (context, repeat), group in sorted(grouped.items()):
        stats = aggregate(group, gold)
        output["contexts"].setdefault(context, {})[str(repeat)] = stats
        all_stats.append((context, repeat, group, stats))
    output["overall"] = aggregate([row for _, _, group, _ in all_stats for row in group], gold)
    for context in CONTEXTS:
        passes = [item for item in all_stats if item[0] == context]
        if passes:
            pooled = [row for _, _, group, _ in passes for row in group]
            output["contexts"][context]["pooled"] = aggregate(pooled, gold)
        if len(passes) == 2:
            output["contexts"][context]["repeat_flips"] = flips(passes[0][2], passes[1][2])
    return output


def aggregate(group: list[dict], gold: dict[str, str]) -> dict:
    choices = Counter(row["choice"] for row in group)
    accepted = {case_id for case_id, label in gold.items() if label == "accepted"}
    fa = sum(row["choice"] == "correct" and row["case_id"] not in accepted for row in group)
    fr = sum(row["choice"] != "correct" and row["case_id"] in accepted for row in group)
    latencies = [float(row["latency_ms"]) for row in group if row.get("latency_ms") is not None]
    accepted_n = sum(label == "accepted" for label in gold.values())
    rejected_n = len(gold) - accepted_n
    repeats = len(group) // len(gold)
    result = {
        "n": len(group),
        "agreement_percent": (100 * (len(group) - fa - fr) / len(group)),
        "false_accepts": fa,
        "false_rejects": fr,
        "false_accept_denominator": rejected_n * repeats,
        "false_reject_denominator": accepted_n * repeats,
        "false_accept_rate_percent": 100 * fa / (rejected_n * repeats),
        "false_reject_rate_percent": 100 * fr / (accepted_n * repeats),
        "choice_counts": dict(sorted(choices.items())),
    }
    if latencies:
        result["latency_ms"] = {
            "sample_n": len(latencies),
            "mean": statistics.mean(latencies),
            "median": statistics.median(latencies),
            "p95": percentile(latencies, 0.95),
        }
    return result


def flips(first: list[dict], second: list[dict]) -> dict:
    left = {row["case_id"]: row["choice"] for row in first}
    right = {row["case_id"]: row["choice"] for row in second}
    binary = sum((left[key] == "correct") != (right[key] == "correct") for key in left)
    three_way = sum(left[key] != right[key] for key in left)
    return {"binary_flips": binary, "three_way_flips": three_way}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("predictions", type=Path)
    args = parser.parse_args()
    try:
        print(
            json.dumps(
                score(args.predictions, Path(__file__).with_name("labels.jsonl")), sort_keys=True
            )
        )
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
